console.log("Portfolio Loaded Successfully");

const year = document.getElementById("year");

year.textContent = new Date().getFullYear();

const themeButton = document.getElementById("theme-btn");

if(localStorage.getItem("theme") === "dark"){

    document.body.classList.add("dark-mode");

    themeButton.textContent = "☀️";

}

themeButton.addEventListener("click", function(){

    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")){

        localStorage.setItem("theme","dark");

        themeButton.textContent="☀️";

    }

    else{

        localStorage.setItem("theme","light");

        themeButton.textContent="🌙";

    }

});

AOS.init({
    duration:1000,
    once:true
});


const roles = [
    "Front-End Developer",
    ".NET Developer",
    "SQA Engineer"
];

const typingElement = document.getElementById("typing");

let roleIndex = 0;
let charIndex = 0;

function typeText(){

    if(charIndex < roles[roleIndex].length){

        typingElement.textContent += roles[roleIndex].charAt(charIndex);

        charIndex++;

        setTimeout(typeText,100);

    }

    else{

        setTimeout(deleteText,1500);

    }

}

function deleteText(){

    if(charIndex > 0){

        typingElement.textContent =
        roles[roleIndex].substring(0,charIndex-1);

        charIndex--;

        setTimeout(deleteText,50);

    }

    else{

        roleIndex++;

        if(roleIndex >= roles.length){

            roleIndex = 0;

        }

        setTimeout(typeText,500);

    }

}

typeText();




emailjs.init("euyRYjeEAK1T-4P_v");

const contactForm = document.getElementById("contact-form");

contactForm.addEventListener("submit", function(e){

    e.preventDefault();

    emailjs.sendForm(

        "service_tz4yi8j",

        "template_xgz5j6c",

        this

    ).then(function(){

        alert("✅ Message Sent Successfully!");

        contactForm.reset();

    }).catch(function(error){

        alert("❌ Failed to Send!");

        console.log(error);

    });

});


const sections = document.querySelectorAll("section");

const navLinks = document.querySelectorAll(".nav-link");

window.addEventListener("scroll", () => {

    let current = "";

    sections.forEach(section => {

        const sectionTop = section.offsetTop - 150;

        const sectionHeight = section.clientHeight;

        if (window.scrollY >= sectionTop) {

            current = section.getAttribute("id");

        }

    });

    navLinks.forEach(link => {

        link.classList.remove("active");

        if (link.getAttribute("href") === "#" + current) {

            link.classList.add("active");

        }

    });

});

const menuToggle = document.getElementById("menu-toggle");
const navMenu = document.querySelector(".nav-links");

menuToggle.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    menuToggle.classList.toggle("active");
});




const navItems = document.querySelectorAll(".nav-link");

navItems.forEach(item => {

    item.addEventListener("click", () => {

        navMenu.classList.remove("active");
        menuToggle.classList.remove("active");

    });

});